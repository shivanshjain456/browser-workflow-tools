import { test, describe, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';

/**
 * bootstrap() is the only entry point the artifact has, and the property that
 * matters most is that it is *idempotent*: a page must never end up with two
 * live instances, because two instances means two contextmenu listeners, two
 * conversions and two downloaded files per right-click.
 *
 * The script runs at `document-start`, where `document.documentElement` does not
 * exist yet, and that is exactly where the marker used to be written somewhere a
 * later injection could not see it. Test 4 below is the regression test for that.
 */

// Must be set before the module is imported: main.js self-starts otherwise.
globalThis.__SIAT_NO_AUTOBOOT = true;
const { bootstrap, SCRIPT_VERSION_REPORTED } = await import('../../src/main.js');

const FLAG = '__saveImageAsTypeInitialised';

let JSDOM = null;
let SKIP_DOM = false;
try {
  ({ JSDOM } = await import('jsdom'));
} catch (err) {
  SKIP_DOM = `jsdom unavailable (${err.code || err.message}) — run \`npm install\` to enable the DOM tests`;
}

let dom = null;
let doc = null;
let listenerAdds = null;

function installDom() {
  dom = new JSDOM(
    '<!doctype html><html data-siat-no-autoboot><body><img id="photo" src="https://cdn.example/photo.jpg" alt="A photo"></body></html>',
    { url: 'https://page.example/gallery', pretendToBeVisual: true },
  );
  doc = dom.window.document;
  globalThis.window = dom.window;
  globalThis.document = doc;
  globalThis.HTMLElement = dom.window.HTMLElement;
  globalThis.Node = dom.window.Node;
  globalThis.Event = dom.window.Event;
  globalThis.MouseEvent = dom.window.MouseEvent;
  globalThis.KeyboardEvent = dom.window.KeyboardEvent;
  // The idle capability probe needs a real canvas/encoder stack; the browser
  // suite covers it. Stubbing the scheduler keeps these tests about booting.
  dom.window.requestIdleCallback = () => 0;

  listenerAdds = new Map();
  const original = doc.addEventListener.bind(doc);
  doc.addEventListener = (type, handler, options) => {
    listenerAdds.set(type, (listenerAdds.get(type) || 0) + 1);
    return original(type, handler, options);
  };
}

function teardownDom() {
  if (dom) dom.window.close();
  dom = null;
  doc = null;
  for (const key of ['window', 'document', 'HTMLElement', 'Node', 'Event', 'MouseEvent', 'KeyboardEvent']) {
    delete globalThis[key];
  }
}

const adds = (type) => listenerAdds.get(type) || 0;

describe('bootstrap — one instance per document', { skip: SKIP_DOM }, () => {
  beforeEach(() => installDom());
  afterEach(() => teardownDom());

  test('boots, reports ready, and publishes the documented API', async (t) => {
    const instance = await bootstrap({ document: doc });
    t.after(() => instance.destroy());
    assert.equal(instance.ready, true, 'ready is only true once boot finished');
    // In the *source* module this is still the build placeholder; build.mjs
    // stamps the real version and lint checks that none survives. What matters
    // here is that diagnostics reports the module's own constant, not a copy
    // that can drift.
    assert.equal(instance.version, SCRIPT_VERSION_REPORTED, 'the reported version is the module constant');
    for (const key of ['menu', 'panel', 'store', 'toaster', 'gm', 'runConversion', 'cancelJob', 'diagnostics', 'capabilityReport', 'resolveTarget', 'destroy']) {
      assert.ok(instance[key] !== undefined, `instance.${key} is exposed`);
    }
    assert.equal(typeof instance.diagnostics, 'function');
    assert.equal(instance.paused, false, 'paused is a live getter, not a copied snapshot');
    assert.equal(adds('contextmenu'), 1, 'exactly one contextmenu listener');
  });

  test('the marker is visible on every root a later injection might check', async (t) => {
    const instance = await bootstrap({ document: doc });
    t.after(() => instance.destroy());
    assert.equal(doc[FLAG], instance, 'marked on the Document');
    assert.equal(doc.documentElement[FLAG], instance, 'marked on <html>');
    assert.equal(doc.body[FLAG], instance, 'marked on <body>');
    assert.equal(dom.window[FLAG], instance, 'marked on the window (same-world handle)');
  });

  test('a second bootstrap returns the same instance and adds no listeners', async (t) => {
    const first = await bootstrap({ document: doc });
    t.after(() => first.destroy());
    const before = adds('contextmenu');
    const second = await bootstrap({ document: doc });
    const third = await bootstrap({ document: doc });
    assert.equal(second, first, 'same instance');
    assert.equal(third, first, 'same instance again');
    assert.equal(adds('contextmenu'), before, 'no duplicate contextmenu listener — one right-click, one conversion');
  });

  test('REGRESSION: booting at document-start (no <html> yet) is still seen by a later injection', async (t) => {
    const realRoot = doc.documentElement;
    // At document-start Chrome has not created <html> yet; the script must cope
    // and still be recognisable once the document has been parsed.
    Object.defineProperty(doc, 'documentElement', { value: null, configurable: true });
    const early = await bootstrap({ document: doc });
    Object.defineProperty(doc, 'documentElement', { value: realRoot, configurable: true });

    const listenersAfterEarlyBoot = adds('contextmenu');
    const later = await bootstrap({ document: doc });
    assert.equal(later, early, 'the injection after parsing reuses the document-start instance');
    assert.equal(adds('contextmenu'), listenersAfterEarlyBoot, 'no second set of listeners (this used to double every download)');
    assert.equal(doc.documentElement[FLAG], early, 'the marker was back-filled onto <html> once it existed');
    t.after(() => early.destroy());
  });

  test('destroy() clears the marker so the script can boot again cleanly', async (t) => {
    const first = await bootstrap({ document: doc });
    first.destroy();
    assert.equal(doc[FLAG], undefined, 'marker removed from the Document');
    assert.equal(doc.documentElement[FLAG], undefined, 'marker removed from <html>');
    assert.equal(dom.window[FLAG], undefined, 'marker removed from the window');
    const second = await bootstrap({ document: doc });
    t.after(() => second.destroy());
    assert.notEqual(second, first, 'a fresh instance after an explicit destroy');
    assert.equal(second.ready, true);
    assert.equal(second.paused, false);
  });

  test('resolveTarget() reports an image and nothing else', async (t) => {
    const instance = await bootstrap({ document: doc });
    t.after(() => instance.destroy());
    const img = doc.getElementById('photo');
    const hit = instance.resolveTarget(img);
    assert.ok(hit, 'an <img> is a target');
    assert.equal(instance.resolveTarget(doc.body), null, 'the page background is not a target by default');
  });
});
