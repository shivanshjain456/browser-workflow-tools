/**
 * Single source of truth for the userscript metadata block.
 *
 * Both `build.mjs` (which renders the header of the distributed artifact) and
 * `test/unit/metadata.test.mjs` (which audits it) import this module, so the
 * declared permissions cannot drift away from what the code actually uses.
 */

export const SCRIPT_VERSION = '2.0.0';

export const META = {
  name: 'Save Image as Type',
  /**
   * `namespace` is an opaque identifier that managers use to tell two scripts
   * with the same name apart — it is never fetched. The `.invalid` TLD is
   * reserved by RFC 2606 and cannot resolve, which makes the intent explicit.
   */
  namespace: 'https://siat.invalid/save-image-as-type',
  version: SCRIPT_VERSION,
  description:
    'Convert images locally: PNG, JPG, WebP, GIF, BMP or PDF. Batch, ZIP, transforms, clipboard, metadata and keyboard workflows. No servers or tracking.',
  author: 'Save Image as Type userscript contributors',
  license: 'MIT',
  /**
   * Deliberately no @homepageURL / @supportURL / @updateURL / @downloadURL:
   * there is no project site or update server, and a manager link that
   * resolves to nothing would be worse than no link at all. Updates are
   * manual — reinstall the .user.js file.
   */
  icon:
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E" +
    "%3Crect width='64' height='64' rx='12' fill='%232563eb'/%3E" +
    "%3Cpath d='M32 14v24m0 0-9-9m9 9 9-9' stroke='white' stroke-width='5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E" +
    "%3Cpath d='M16 46h32' stroke='white' stroke-width='5' stroke-linecap='round'/%3E" +
    '%3C/svg%3E',

  /**
   * This tool is deliberately site-agnostic: its whole purpose is to act on an
   * image on whatever page the user happens to be reading, which is the same
   * reason the browser extension it is ported from needs the "<all_urls>"
   * permission. http/https only (no file://, no privileged browser pages).
   */
  match: ['*://*/*'],
  exclude: [],

  /**
   * document-start so the contextmenu listener exists before the user can
   * possibly right-click on a slow SPA. Everything expensive (feature probing,
   * settings load, DOM creation) is deferred until first interaction or idle.
   */
  runAt: 'document-start',

  /** Frames are intentionally allowed: right-clicking an image inside an
   *  iframe must work, and each frame owns its own menu instance. */
  noframes: false,

  /**
   * Every grant below is used by the code; `test/unit/metadata.test.mjs` fails
   * the build if a grant is declared but unused, or used but undeclared.
   */
  grant: [
    'GM_info', // manager/version/downloadMode detection -> diagnostics + download strategy
    'GM_getValue', // read persisted settings
    'GM_setValue', // write persisted settings
    'GM_addValueChangeListener', // sync settings between open tabs
    'GM_removeValueChangeListener', // release that listener when the page tears down
    'GM_deleteValue', // "Reset to defaults" removes the stored key entirely
    'GM_xmlhttpRequest', // fetch cross-origin image bytes (CORS bypass, the <all_urls> equivalent)
    'GM_download', // save the converted file with the manager's download pipeline
    'GM_registerMenuCommand', // manager menu entries: settings / diagnostics / pause
    'GM_notification', // surface failures when the in-page toast is not visible
  ],

  /**
   * Wildcard on purpose and only for image fetches: an image can be hosted on
   * any CDN, and the whole point is to reach the ones that do not send
   * Access-Control-Allow-Origin. The fetch is only ever issued when the user
   * explicitly picks a format, only for that one URL, and can be disabled in
   * settings (`allowCrossOriginFetch`).
   */
  connect: ['*'],
};

const KEY_ORDER = [
  'name',
  'namespace',
  'version',
  'description',
  'author',
  'license',
  'homepageURL',
  'supportURL',
  'icon',
  'match',
  'exclude',
  'run-at',
  'noframes',
  'grant',
  'connect',
];

function metaValue(key) {
  if (key === 'run-at') return META.runAt;
  if (key === 'noframes') return META.noframes ? '' : null;
  return META[key];
}

/** Renders the `// ==UserScript== ... // ==/UserScript==` block. */
export function renderMetadata(meta = META) {
  const lines = ['// ==UserScript=='];
  const push = (key, value) => {
    if (Array.isArray(value)) {
      for (const item of value) lines.push(`// @${key.padEnd(12)}${item}`);
    } else if (value === '' || value === true) {
      lines.push(`// @${key}`);
    } else if (value != null) {
      lines.push(`// @${key.padEnd(12)}${value}`);
    }
  };
  for (const key of KEY_ORDER) push(key, metaValue(key));
  // Any future keys not in KEY_ORDER still get emitted (alphabetical) so nothing
  // silently disappears from the distributed header.
  for (const key of Object.keys(meta).sort()) {
    if (KEY_ORDER.includes(key) || key === 'runAt' || key === 'noframes') continue;
    push(key, meta[key]);
  }
  lines.push('// ==/UserScript==');
  return lines.join('\n');
}
