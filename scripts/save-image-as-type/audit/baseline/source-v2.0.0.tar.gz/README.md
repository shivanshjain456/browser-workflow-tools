# Save Image as Type — userscript

Right-click any image on any page and save it locally as **PNG, JPG, WebP, GIF, BMP or PDF** — or re-save the
**original file** byte-for-byte. Everything happens in your browser: the conversion, the encoders for the formats
browsers cannot write, and the file naming. No server, no account, no telemetry.

This is a userscript port of the Chrome extension of the same name. The deliverable is a single installable file:

```
release/save-image-as-type.user.js      (v2.0.0, ~560 KB, no runtime dependencies)
```

## New in 2.0.0 — exactly ten feature sets

| # | Capability | Practical benefit / where to use it |
|---|---|---|
| 1 | Batch conversion | **Save all images on this page…** previews counts/options, then converts with bounded concurrency, progress, Cancel and safe recovery. Optional extra formats per image. |
| 2 | Image inventory / picker | **Browse page images…** lists dimensions, type, origin and loading state; search/filter/sort, select rows or use **This one**. No preview downloads. |
| 3 | ZIP export | **Save as ZIP**, or choose ZIP in the batch dialog, for one download instead of many. UTF-8 names, collision suffixes and CRC-32. |
| 4 | Transform before save | **Transform and save…** offers aspect-locked resize, presets, crop, 90° rotation and flips, with preview and **Make default**. |
| 5 | Image clipboard | **Copy image to clipboard** pastes an image into other apps; uses PNG where required and explains permissions/context failures. |
| 6 | Filename templates | Settings → filename template: tokens such as `{host}-{w}x{h}`, `{base}`, `{index3}`, `{preset}`, date and alt/title. Preview and validation included. |
| 7 | Presets + host auto-apply | Bundle format, quality, naming, subfolder, ZIP destination and transform; optionally apply automatically to exact/wildcard page hosts. |
| 8 | Format comparison | **Compare formats…** shows actual encoded sizes and transparency effects before **Save smallest** or an individual format. |
| 9 | Metadata inspector / sanitizer | **Inspect metadata** shows EXIF/XMP/ICC and GPS risk, then **Save original without metadata** removes supported container fields without re-encoding pixels. |
| 10 | Keyboard workflow | Hover + `Alt+Shift+S` save, `C` copy, `P` picker, `A` batch, `X` cancel. Rebind in Settings; help in the manager menu; digits 1–9 select menu formats. |

See [the decision and acceptance table](docs/v2-feature-decisions.md) for approaches, edge cases and observable tests.
Shared dialogs, tests, migration and build improvements are foundations, not additional counted features.

---

## 1. Install

The script has **no `@updateURL` / `@downloadURL`** (see [Permissions](#5-permissions-and-why-they-are-needed)), so
updates are manual: re-install the file when you get a new one.

### Tampermonkey

1. Open the Tampermonkey dashboard → **Utilities** tab.
2. Under *File*, choose `release/save-image-as-type.user.js` → **Install**.
   (Or drag the file onto the dashboard, or use *Install from URL* if you host it yourself.)
3. Confirm the permission prompt. Tampermonkey lists the `@grant` permissions from the metadata block; they are
   itemised with their justification in [§5](#5-permissions-and-why-they-are-needed).

**One Tampermonkey setting matters for downloads.** By default Tampermonkey saves through a native
`<a download>` click, which means the browser's own download behaviour: file names work, but a *sub-folder* and a
forced *Save As* dialog do not. To get those, switch Tampermonkey to browser-API download mode
(*Settings → Config mode: Advanced → Download mode: "Browser API"*), and — if you want formats other than the
browser's usual ones — add the extensions to Tampermonkey's download whitelist (*Settings → Download → File
extension whitelist*: `png jpg jpeg webp gif bmp pdf avif zip`). If an extension is not whitelisted, this script does not
fail: it falls back to a normal browser download and tells you why in the toast.

### Violentmonkey

1. Open the Violentmonkey dashboard → **＋ New** → *Install from file* (or drop the `.user.js` file onto the
   dashboard).
2. Confirm the permission prompt.

Violentmonkey documents limitations on sub-paths in `GM_download` names. The script uses
`GM_info.downloadMode` and drops the sub-folder setting with a one-time explanation instead of producing a file
named `refs/2026/shot.png` literally. Browser-API mode may improve download control, but real Violentmonkey sub-folder/Save As behaviour was not tested; treat folders as best effort.

### Which managers and browsers were actually tested

See [docs/verification-report.md](docs/verification-report.md). Summary: the shipped artifact was run in
**Chrome 131 (headless, Linux)** against a **purpose-built emulation of the manager API**
(`GM_*` implemented over local HTTP endpoints), plus jsdom for the DOM-level unit tests. It was **not** run inside a
real Tampermonkey or Violentmonkey installation, and not in Firefox or Safari — manager capabilities are detected at runtime, but "works in Tampermonkey 5.x" is not a claim this
repository can back with evidence.

---

## 2. Use

| Action | What happens |
| --- | --- |
| **Right-click an image** | The script's menu replaces the browser's, listing your enabled formats plus **Settings**. |
| **Shift + right-click** | Always the *browser's* own menu — the documented escape hatch. |
| **Long-press (touch)** | 550 ms press opens the same menu (12 px of finger jitter tolerated). |
| **Keyboard** | `↓`/`↑` or `Tab`/`Shift+Tab` move, `Home`/`End` jump, `Enter`/`Space` pick, `Escape` closes, focus is trapped inside the menu and returned to the page afterwards. |
| **Manager menu** | Four commands are registered: *Settings…*, *Convert the last image I pointed at…*, *Capability report*, *Pause on this page*. |

Recognised targets: `<img>` (including `srcset` candidates), inline `<svg>`, elements with a CSS
`background-image`, and images inside iframes (the script has no `@noframes`, so every frame gets its own menu).
Lazy-loaded and re-rendered (SPA) images work: listeners are delegated on `document` with capture, so nodes that
did not exist at load time — or that were replaced after a framework re-render — are handled without
re-initialising.

Progress and results appear as toasts in the bottom-right corner. The toast stack is capped at four, never covers
the whole page, and lets clicks through to the page except on the toast itself.

---

## 3. Formats

| Menu entry | Engine | Transparency | Notes |
| --- | --- | --- | --- |
| **PNG** | `canvas.toBlob('image/png')` | yes | Lossless. |
| **JPG** | `canvas.toBlob('image/jpeg')` | flattened | Quality is a setting; transparency is composited onto the flatten-background colour. |
| **WebP** | `canvas.toBlob('image/webp')` | yes | Quality is a setting. |
| **GIF** | **built-in encoder** (GIF89a, median-cut palette, LZW) | indexed (1-bit) | 256 colours. Animation is kept when the browser can decode frames (see below). |
| **BMP** | **built-in encoder** (BITMAPV5 with alpha masks, or 24-bit V3) | yes, lossless | Verified bit-exact against the source pixels, alpha included. |
| **PDF** | **built-in encoder** (single page, DCTDecode JPEG) | flattened | Page size `a4`/`letter` (fit, keep aspect) or `pixel` (1 px = 0.75 pt). |
| **AVIF** | `canvas.toBlob('image/avif')` | yes | **Hidden unless a runtime probe proves the browser really encodes AVIF.** Chrome 131 silently returns a PNG for `image/avif`, so the entry is not offered there. |
| **Original file** | passthrough | as source | Re-saves the exact source bytes (verified: identical SHA-256). Keeps animation and quality; needs the bytes to be readable. |

Why built-in encoders: browsers cannot encode BMP or GIF from a canvas, and they do not fail loudly — `toBlob`
returns a **PNG** while claiming success. The script therefore verifies `blob.type` for every native encode and
ships its own BMP/GIF/PDF writers. No `@require` is used: nothing executable is fetched from a third party, ever.

**Animated GIF.** Keeping frames needs WebCodecs (`ImageDecoder`). The script probes it at runtime, and reports what
it found in Settings → Diagnostics and in the toast notes:

* Chrome 131 on a secure context (`https://`, or `http://127.0.0.1`): `ImageDecoder` is present and
  `isTypeSupported('image/gif')` is true → a 4-frame fixture came out as 4 frames with the original 100 ms delays
  (verified with Pillow).
* On a plain `http://` page (not localhost) the page is **not** a secure context, WebCodecs is not exposed, and the
  GIF holds the first frame only — the toast says so and points you at *Original file*.
* If the frames cannot be read for any other reason, the script never pretends: the note explains it and the output
  is an honest single-frame GIF.

---

## 4. Settings

Open with **Settings** at the bottom of the right-click menu, or the manager menu command. Settings are stored
through `GM_getValue`/`GM_setValue` under the key `siat.settings.v3`; without a storage grant they live in memory
for the page load and the panel says so. There is also **Reset defaults**, **Export JSON** and **Import JSON**
(imported files are validated and sanitised; a hostile file cannot inject markup, paths or scripts).

| Setting | Default | Effect |
| --- | --- | --- |
| Formats in the right-click menu | PNG, JPG, WebP, GIF, BMP, PDF, Original | Which entries appear, in this order. Unticked formats stay available in Settings only. AVIF appears only where the encoder probe succeeds. |
| Instant download (`downloadBehavior`) | `instant` | `instant` skips the Save As dialog where the manager allows it; `ask` requests it. Only meaningful in browser-API download mode. |
| File-name prefix (`filenamePrefix`) | empty | Prepended to every saved name. |
| Sub-folder (`subfolder`) | empty | Saves into `Downloads/<subfolder>/`. **Only works when the manager reports `downloadMode: "browser"`** — otherwise it is dropped and you are told once. |
| Max file-name length | 64 | Truncates the base name (extension always kept), 8–120. |
| Flatten background | white | Used when the target format cannot store transparency (JPG, PDF). |
| JPEG quality | 0.92 | |
| WebP quality | 0.90 | |
| PDF page fit | `a4` | `a4`, `letter` or `pixel`. |
| Keep animation | on | Try to keep every frame when converting to GIF. |
| Max GIF frames | 100 | Frames are subsampled (delays stretched to keep total duration) above this. |
| GIF memory limit | 512 MB | Refuses (or scales frames down) rather than crashing the tab. |
| Downscale above | 40 MP | Very large images are reduced before encoding; `0` = never. |
| Fetch cross-origin images through the manager | on | The CORS bypass. Turn it off and cross-origin images that do not send `Access-Control-Allow-Origin` produce an explanation instead of a file. |
| Enable CSS background images | on | Treat `background-image` elements as targets. |
| Enable long-press | on | Touch long-press opens the menu. |
| Intercept right-click | on | Off restores the browser menu everywhere. |
| Require Shift | off | Inverts the rule: only Shift+right-click opens this menu. |
| Remember last format | on | Puts your last used format first. |
| Notify on error | on | Also raises a `GM_notification` when the in-page toast may not be visible. |

### New settings and migration

Installing 2.0.0 over the existing script keeps the same name/namespace. Schema v2 settings are read and migrated
into `siat.settings.v3`; existing choices are preserved and the new fields receive defaults. The old key remains
as a downgrade backup. Reinstalling v1 reads that older snapshot, **not** changes made later in v2.
Export settings before upgrading/downgrading if you need a portable backup. Imports are validated; unsupported
format choices and invalid templates/bindings are reported or repaired, not executed as code.

| Group | Defaults / semantics |
|---|---|
| Batch | 2 concurrent images (1–4); 200 images/run; deduplicate URLs; skip icon-sized images; not-loaded sources excluded; separate files; optional extra output formats |
| ZIP | 512 MiB buffer target; overflow is checked between images with an 8 MiB grace allowance; later outputs saved separately, already-buffered outputs archived. Independent writer ceiling 1 GiB. In-memory, not streaming. |
| Picker | CSS-background scan enabled, 2500 styled elements; hard caps 1000 entries, 8 frames × 200 frame images; at most 200 displayed rows / 48 thumbnail attempts per render |
| Templates | Off (empty) by default; template replaces filename prefix; collision suffix enabled inside a run; normal maximum filename length still applies |
| Presets | None by default, max 12; up to 8 host rules each; manual selection wins over host matching; longest/specific rule wins, declaration order breaks ties |
| Transforms | No default transform; **Make default** applies to subsequent conversions until cleared in settings; original-byte passthrough refuses active transforms |
| Clipboard | PNG render by default; optional original when supported, otherwise PNG re-encode; no new userscript clipboard grant |
| Comparison | PNG/JPG/WebP; up to six sequential candidates; transparency-aware choice, lossless preference within 2% of smallest |
| Metadata | Strip-on-original off; keep ICC by default; GPS warning on. EXIF orientation is not baked into pixels by stripping, so displayed orientation may change. |
| Keyboard / UI | Shortcuts and six extra menu actions on; job bar on. Even with job bar hidden a running batch has a toast Cancel control. |

**Recovery is conservative.** Conversions do not automatically retry writes. Cancel stops queued work, but a save
already handed to the browser/manager may still land; a partial ZIP may contain completed outputs. Definite manager
refusals (for example a missing extension whitelist entry) may use the browser fallback. **Timeout, thrown,
`not_succeeded` and unknown download outcomes do not trigger another download**: check the downloads folder first.
Retry only replays wholly failed, safely retryable batch items, never partial or unconfirmed items. Select missing
outputs manually to recover those cases. Jobs and buffers are memory-only; there is no resume after tab close/reload.

The panel ends with a read-only **Diagnostics** table (manager, versions, injection mode, download mode, storage
backend, per-format encoder results, frame-decoding support) and a one-line **capability report** you can copy into
a bug report.

---

## 5. Permissions, and why they are needed

```
// @match       *://*/*
// @run-at      document-start
// @connect     *
// @grant       GM_info, GM_getValue, GM_setValue, GM_deleteValue,
//              GM_addValueChangeListener, GM_removeValueChangeListener,
//              GM_xmlhttpRequest, GM_download, GM_registerMenuCommand, GM_notification
```

| Permission | Why |
| --- | --- |
| `@match *://*/*` | The tool is "any image on any page". It is limited to `http`/`https` — no `file://`, no `chrome://`, no extension origins. |
| `@connect *` | Images live on arbitrary CDNs. The wildcard is used **only** for the single URL the user just right-clicked, only when the page's own CORS policy blocks reading its pixels, and it can be switched off in settings. |
| `@run-at document-start` | Listeners must exist before the page's own scripts run, so a right-click is never missed on a fast-loading or SPA page. Nothing expensive happens at that point: only listener registration. |
| `GM_info` | Detects manager, version, `downloadMode` and injection world — this decides the download strategy and what the diagnostics show. |
| `GM_getValue` / `GM_setValue` | Persist your settings. |
| `GM_deleteValue` | *Reset defaults* removes the stored key entirely. |
| `GM_addValueChangeListener` / `GM_removeValueChangeListener` | Keep settings in sync across open tabs; the listener is released on page teardown. |
| `GM_xmlhttpRequest` | Read the bytes of a cross-origin image that does not send CORS headers. Without it those images cannot be converted, and the script says exactly that instead of writing a broken file. |
| `GM_download` | Save through the manager's download pipeline (sub-folder, Save As, whitelist). Falls back to a browser download when unavailable or refused. |
| `GM_registerMenuCommand` | The four manager-menu entries. |
| `GM_notification` | Surface a failure when the in-page toast might not be visible. |

**Execution world:** the default (the manager's sandbox where one exists). The script never uses `unsafeWindow` and
never touches page JavaScript objects; the page sees only two custom elements (`#siat-menu-host`, `#siat-toast-host`,
plus `#siat-panel-host` while Settings is open) and one global handle
(`window.__saveImageAsTypeInitialised`) used by the manager-menu commands and by tests.

**No `@require`, no `@resource`, no `@updateURL`, no `@downloadURL`.** A `@require` of a third-party encoder library
would mean unpinned remote executable code inside a script that already has cross-origin fetch permission — the
supply-chain risk is not worth it when BMP/GIF/PDF encoders are a few hundred lines that can be tested directly. No
update URL means no silent remote changes: you decide when to install a new version. A lint rule fails the build if
a remote executable dependency or an unexpected URL ever appears in the artifact.

---

## 6. Privacy: what leaves your device

* **No analytics, telemetry, crash reporting or author-controlled network service.** Conversions, comparisons,
  metadata inspection and archive construction run on your device; no image is uploaded for processing.
* **Network destinations:** the original image URL you act on, or URLs in a batch/picker selection that you
  explicitly confirm. Same-origin reads use the page fetch API; CORS-blocked image bytes can be fetched using
  `GM_xmlhttpRequest`. Normal HTTP redirects made by the image host may lead to its CDN or signed destination.
  Those servers can receive ordinary browser/manager request headers and cookies according to their policies.
  No authentication, CAPTCHA, access restriction or permission is bypassed. Cross-origin fetching can be disabled.
* **No network for inventory or thumbnails.** Scanning reads the DOM; unavailable previews are labelled rather
  than fetched. “Load selected images first” is an explicit bandwidth-using action and can change page `src`/loading
  attributes. Animation/original/metadata actions may re-read the selected image's encoded bytes. The final save
  uses a local Blob URL via the manager or browser, not an upload endpoint.
* **Stored data:** settings under `siat.settings.v3` in your manager's storage. This includes presets you create,
  their explicitly entered page-host rules, filename templates, transform defaults and shortcut bindings.
  It does **not** store image bytes, inspected GPS/EXIF values, inventory/history, visited URLs or analytics IDs.
  Keys `siat.settings.v2`, `siat.settings`, and `saveImageAsType.settings` are migration inputs and are retained,
  not rewritten, as downgrade backups. No page `localStorage`, `sessionStorage`, IndexedDB or cookies are written.
  Export JSON writes your configuration to a file you choose. Clipboard images go to the **system clipboard**
  only when you request Copy; other apps with clipboard access may read them.
* Page-controlled text (file names, `alt` text, URLs) is only ever written with `textContent`, never as HTML; there
  is no `eval`, no `new Function`, no `innerHTML` sink anywhere in the source (enforced by lint and by tests).
* The end-to-end suite asserts the network claim: during a conversion, every request went to the fixture origins and
  nothing else (`no-network-beyond-the-image`).

---

## 7. Known limitations (stated plainly)

* **Not verified in a real manager.** All browser testing used an emulation of the `GM_*` API. Manager-specific
  behaviours that could not be reproduced — Tampermonkey's real extension whitelist dialog, Violentmonkey's real
  `downloadMode` toggle, the native Save As dialog, cross-tab storage sync — are handled by feature detection and
  documented fallbacks, but they are **not** evidence-backed.
* **Inventory is bounded, not exhaustive.** Cross-origin frame DOM, closed shadow roots, nested shadow structures,
  virtualised/offscreen content and site-specific lazy-loading schemes may not be listed. Use right-click in a
  frame or load the desired content normally; the script does not bypass those boundaries.
* **Clipboard** requires secure context, focus, permission and browser support; real user-gesture behaviour varies.
* **ZIP and transforms** run in memory/on the main thread; large images/archives can cause pauses. No streaming ZIP,
  persisted jobs or GPU/worker codec guarantee. Browser multi-download policy still applies to separate-file batches.
* **Comparison** encodes candidates once for measurement; Save re-acquires/re-encodes the selected format.
  If the page/image/settings changes between comparison and Save, its result may change. Animated/translucent GIF
  output is palette/1-bit limited; “smallest” is not a perceptual-quality metric.
* **Metadata removal is container-specific, not a privacy certification.** JPEG/PNG/WebP/GIF supported fields only;
  unsupported or structurally unreadable data is retained with a note. Visible watermarks, pixels, server-side
  records, and arbitrary unknown proprietary fields are not sanitised.
* **Development dependencies:** the recorded `npm audit` reports 8 high-severity findings in the pinned Puppeteer
  download/proxy dependency chain (0 production dependencies with findings). These are not bundled in the userscript.
  See the [verification report](docs/verification-report.md#dependency-audit) before using the development tooling
  with untrusted archives/proxies. This release is not a claim of a clean development dependency audit.
* **AVIF** is offered only where the runtime probe succeeds; on Chrome 131 it does not, so you will not see it.
* **GIF** is 256 colours with 1-bit transparency. Fully transparent pixels are supported, but partial alpha and
  the original RGB values hidden behind transparent pixels cannot be preserved exactly. Palette quantisation
  can also alter visible colours; it is not a lossless alternative to PNG.
* **Animation** needs WebCodecs, i.e. a secure context. See [§3](#3-formats).
* **Sub-folder and forced Save As** need browser-API download mode; otherwise the setting is ignored with a notice.
* **PDF** output is a single page with the image embedded as JPEG — not a vector or multi-page document.
* Very large images are downscaled above the configured megapixel budget rather than risking a tab crash.
* `file://` pages are not matched. Images inside **cross-origin** iframes get their own instance (no `@noframes`),
  but only the same-origin iframe case is covered by tests.

---

## 8. Repository layout and development

```
src/meta.js            metadata block (single source of truth) + permission justifications
src/main.js            bootstrap(), idempotency, manager menu commands, orchestration
src/core/              gm adapter, settings store, source acquisition, conversion, download, frames
src/encoders/          BMP, GIF (median-cut + LZW), PDF, ZIP (store + CRC-32)
src/ui/                shared modal kit, menu, settings, picker, batch, jobbar, transform, compare, inspector, help, toast
build.mjs              dependency-free bundler → release/save-image-as-type.user.js (+ --check staleness gate)
lint.mjs               23 static checks (forbidden constructs, grant↔usage, scope, artifact integrity)
test/unit/             513 tests (node:test + jsdom); encoders verified against Pillow/pypdf
test/browser/          57 end-to-end scenarios in Chrome via puppeteer, over two local origins
test/helpers/          verify_media.py (independent Pillow/pypdf decoder), make_fixtures.py
tools/                 probe-encoders.mjs, probe-codecs.mjs (browser capability probes)
docs/                  verification-report.md, v2-feature-decisions.md, e2e-report-v2-run{1,2}.json
```

```bash
npm install                 # jsdom + puppeteer (dev only; the shipped script needs neither)
npm run build               # regenerate release/save-image-as-type.user.js
npm run build:check         # fail if the artifact is stale relative to src/
npm test                    # 513 unit tests
npm run test:browser        # 57 browser scenarios (needs Chrome + Pillow/pypdf for byte-level checks)
npm run lint                # 23 static checks
npm run test:all            # build + unit + browser
pip3 install --user Pillow pypdf   # optional: independent media verification; tests skip with a reason without it
```

The browser suite serves two origins locally (a gallery page and a "CDN" that withholds CORS headers), injects the
built artifact before page load using an emulated manager API, and verifies saved bytes with Pillow/pypdf — an independent decoder, not
the script's own encoders.

## 9. Verification status

`docs/verification-report.md` records, per check: what was run, what it proved, and what could not be performed.
At the time of writing: **513/513 unit tests**, **23/23 lint checks**, artifact **in sync** with sources, and
**57/57 browser scenarios passing in two consecutive final-artifact runs** (Chrome 131 headless, emulated manager API).

## License

MIT.
