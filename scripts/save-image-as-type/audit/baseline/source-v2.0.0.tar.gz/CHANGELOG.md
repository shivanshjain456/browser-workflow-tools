# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); the project uses semantic versioning.

## 2.0.0 — 2026-10-16

### Exactly ten added feature sets

1. **Batch conversion:** preview/confirm, multi-format outputs, bounded concurrency, progress, cancel and safe retry.
2. **Page inventory/picker:** dimensions/type/origin/state, search/filter/sort, local thumbnails and selection.
3. **ZIP export:** one download for a selection/batch; UTF-8 names, collision suffixes, CRC-32 and buffer limits.
4. **Transform before save:** resize, aspect lock, presets, crop, 90° rotation, flips, preview and stored defaults.
5. **Image clipboard:** browser capability/MIME detection, PNG re-encoding and actionable permission failures.
6. **Filename templates:** validated tokens, live settings preview, counters and per-run collision handling.
7. **Presets + per-host auto-apply:** reusable format/quality/naming/transform/destination choices with explicit rules.
8. **Format comparison:** actual encoded byte counts, transparency-aware smallest-good choice and save confirmation.
9. **Metadata inspector/sanitizer:** EXIF/GPS/XMP/ICC findings and supported metadata stripping without pixel re-encoding.
10. **Keyboard workflow/help:** hover-target modifier chords, custom binding validation, help and digit menu selection.

### Foundations and fixes (not counted as features)

- Shared labelled shadow-DOM modal primitive, focus/Escape lifecycle, bounded scan/preview/observer ownership.
- True concurrent queue dispatch (tested with peak-active counters), timeout classification and destroyed-queue guards.
- Preset quality 0 retains “inherit” through import/reload; default transforms reach single and batch conversions.
- Correct EXIF string/byte marker detection and WebP size reads; independent Pillow fixtures verify GPS removal
  and pixel identity, rather than testing a reader against its own writer.
- Correct picker single-row argument routing, transform format IDs/readout, aspect lock after crop/rotation,
  stale/out-of-order preview release, and batch-dialog option overrides/Start guards.
- Bounded frame/style scans and proper sibling traversal; SVG thumbnail URLs released even on preview failure.
- GIF no longer labelled lossless in near-size comparison preference (palette quantisation is lossy).
- Reproducible source-synced v2 metadata/package version, expanded units, 19 new browser scenarios and independent
  Python metadata/ZIP verifiers. Raw final evidence and limitations documented in `docs/verification-report.md`.

### Deliberate behaviour and storage changes

- Schema v3 at **`siat.settings.v3`** reads/migrates v2 and legacy shapes without resetting valid existing choices;
  old keys remain downgrade backups. New presets, host rules, bindings and defaults are configuration only; no
  image bytes, metadata findings, browsing history or persistent job state are stored.
- Six extra right-click actions and four extra manager commands (eight total); new shared dialogs and job bar.
  Batch Cancel remains available in a toast when the job bar is hidden.
- **Safer non-idempotent recovery:** timeout, thrown, `not_succeeded` and unknown download outcomes now report
  uncertainty rather than silently starting a second browser download. Definite refusals still have the old fallback.
  Retry excludes partial/unconfirmed batch saves; check downloads and manually select missing outputs instead.
- Same ten grants and broad any-image match/connect scope as v1, with documented justifications. **No new grant,
  runtime dependency, remote executable resource or automatic update URL.** Reinstall the file manually.
- Dev-only dependency audit is not clean: eight high findings in the pinned Puppeteer download/proxy chain are
  disclosed, not suppressed; they are absent from the self-contained runtime. Real managers/public sites and
  browsers beyond the recorded headless Chrome environment remain unverified.

## 1.0.0 — first release

Userscript port of the "Save Image as Type" Chrome extension: right-click any image and save it locally in another
format. Single self-contained artifact (`release/save-image-as-type.user.js`), no `@require`, no remote code, no
telemetry.

### Added

* **Targets:** `<img>` (including `srcset`), inline `<svg>`, CSS `background-image` elements, and images inside
  iframes (no `@noframes`). Long-press (550 ms, 12 px jitter tolerance) for touch. Shift+right-click always yields
  the browser's own menu.
* **Formats:** PNG, JPG, WebP (native `canvas.toBlob`, with the returned `blob.type` verified), GIF, BMP and PDF
  (hand-written encoders), *Original file* (byte-exact passthrough), and AVIF gated behind a runtime encode probe.
* **Animated GIF** output through WebCodecs `ImageDecoder`, bounded by a frame count and a raw-memory budget, with
  honest reporting when frames cannot be read.
* **Settings** (shadow-DOM modal, keyboard operable, export/import/reset): menu formats, instant download vs. Save
  As, file-name prefix, sub-folder, max name length, flatten background, JPEG/WebP quality, PDF page fit, animation
  and memory limits, downscale threshold, cross-origin fetch switch, background-image and long-press toggles,
  Shift-only mode, remember-last-format, error notifications. Stored under `siat.settings.v2` with a migration from
  the pre-schema (v1) shape.
* **Manager integration:** four `GM_registerMenuCommand` entries (Settings, Convert last hovered image, Capability
  report, Pause on this page); download strategy chosen from `GM_info.downloadMode` with fallbacks to a browser
  `<a download>`; `GM_notification` for failures.
* **UI hygiene:** all UI lives in shadow roots, text is written only via `textContent`, the toast stack is capped at
  four and lets clicks through, the menu is clamped inside the viewport and dismissed on scroll/resize/blur.
* **Tooling:** dependency-free bundler with a staleness gate (`build.mjs --check`), 23 static lint checks
  (`lint.mjs`), 204 unit tests, 38 browser end-to-end scenarios over two local origins, and independent media
  verification with Pillow/pypdf (`test/helpers/verify_media.py`).

### Fixed during development (each found by a test, not by inspection)

These are recorded because they are the failure modes most likely to return:

* **Settings dialog could not be dismissed** — `panel.js` defined `open()`/`close()` only as methods of the returned
  object, so the internal calls resolved to the page's `window.close()`/`window.open()`: Cancel, Escape, the ✕ and a
  successful Save all did nothing (leaving a full-screen backdrop swallowing every click), and *Reset defaults*
  opened a blank popup tab. Fixed by hoisting both into real closure functions; a lint rule
  (`no-implicit-page-globals`) and 10 unit tests now guard the class of bug.
* **A second instance per page** — the idempotency marker was written to `document.documentElement` when it existed
  and to the `Document` otherwise, but only ever read back from one of them. Booting at `document-start` (no `<html>`
  yet) meant a later injection could not see the first instance and started a second: duplicate listeners, duplicate
  manager menu commands, and toasts from two owners in one stack. Fixed by reading/writing the marker on every root
  (`document`, `<html>`, `<body>`, `window`) before the first `await`, with a `ready` flag for callers; verified with
  CDP `DOMDebugger.getEventListeners` counts in the browser suite.
* **Menu vanished when the page was still settling** — any `scroll` event dismissed the menu, including the one a
  page emits right after `scrollIntoView`/smooth scrolling, so the menu flashed open and shut. Fixed with a 150 ms
  grace window that applies to `scroll` only (resize, blur and pagehide still dismiss immediately).
* **Animated GIF silently lost its animation** — frames can only be read from the encoded bytes, but same-origin
  images are acquired as pixels, so `keepAnimation` had nothing to work with and no note explained the loss. The
  source file is now re-read for the animation path (same-origin via `fetch`, cross-origin only through the manager
  and only when the user left that switch on), and a failure to read it is disclosed in the toast.
* **Chromium reports `0×0` on a GIF `ImageDecoder` track** until a frame is decoded, which made the script give up
  and write a single frame. Frame 0 is now decoded to learn the real dimensions and then reused.
* **`ImageDecoder` was handed a whole allocation pool** — `bytes.slice().buffer` on an offset view (a Node `Buffer`,
  or a subarray of a larger fetch) passes unrelated memory to the decoder. Replaced with an exact-size copy.
* **Toast stack bound was per-instance** — with the shared host adopted by a second instance (two managers installed
  at once), each capped its own entries and the visible stack could exceed four. The bound is now enforced on the
  nodes actually on screen.
* **"Settings were repaired" on every page load** — a manager without a storage grant was reported as a *recovery*,
  which triggered the repair toast everywhere. It is now reported honestly as a limitation (memory-only storage) in
  the settings panel and diagnostics, without claiming damage.
* **`menu.attach()` stacked listeners** — it was called after every settings save with no idempotence guard.
* Earlier fixes from the encoder and core work: GIF `expandChannel >> 5` darkened saturated colours; the GIF frame
  delay was read one byte early; percent-decoding destroyed multi-byte UTF-8 and `data:`/`blob:` base names; the
  classic-API override probed only the capital-H `GM_xmlHttpRequest` spelling; unversioned current-schema settings
  were routed through the v1 migration and lost keys; a first run was reported as a recovery; long-press accumulated
  three document listeners per touch-down; `ensureHost()` duplicated the menu host; and a missing `GM_xmlhttpRequest`
  grant was blamed on the cross-origin *setting* instead of naming the grant.

### Known limitations

See README §7. In short: not verified inside a real Tampermonkey/Violentmonkey installation; AVIF hidden where the
browser cannot encode it; GIF animation requires a secure context; sub-folder and forced Save As require
browser-API download mode; PDF output is a single JPEG-embedded page.
